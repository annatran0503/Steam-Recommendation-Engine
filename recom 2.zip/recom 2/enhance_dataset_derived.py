import pandas as pd
import numpy as np
import re

print("="*80)
print("ENHANCING STEAM DATASET - DERIVED FEATURES ONLY")
print("="*80)
print("\nThis script creates features derived ONLY from the original 4 columns:")
print("  - user_id, game_title, behavior_name, value")
print("  - No simulated or random data will be added")
print("="*80)

# Read the original dataset
print("\n1. LOADING ORIGINAL DATASET...")
df = pd.read_csv('../recom 1/steam-200k.csv', header=None, 
                 names=['user_id', 'game_title', 'behavior_name', 'value', 'unused'])

# Drop the unused column
df = df.drop('unused', axis=1)

print(f"   Dataset loaded: {len(df):,} rows")
print(f"   Unique users: {df['user_id'].nunique():,}")
print(f"   Unique games: {df['game_title'].nunique():,}")

# Separate purchases and plays
purchases = df[df['behavior_name'] == 'purchase'].copy()
plays = df[df['behavior_name'] == 'play'].copy()

print(f"   Purchases: {len(purchases):,}")
print(f"   Plays: {len(plays):,}")

# ============================================================================
# GAME-LEVEL FEATURES (derived from game_title and aggregated behaviors)
# ============================================================================
print("\n2. CALCULATING GAME-LEVEL FEATURES...")

# Calculate game statistics from actual data
game_stats = pd.DataFrame({
    'game_title': df['game_title'].unique()
})

# Purchase count (number of unique users who purchased)
game_stats['purchase_count'] = game_stats['game_title'].map(
    purchases.groupby('game_title')['user_id'].nunique()
).fillna(0).astype(int)

# Play statistics
play_stats = plays.groupby('game_title').agg({
    'value': ['sum', 'mean', 'count', 'max', 'min']
}).reset_index()
play_stats.columns = ['game_title', 'total_hours', 'avg_hours', 'play_count', 'max_hours', 'min_hours']

game_stats = game_stats.merge(play_stats, on='game_title', how='left')
game_stats = game_stats.fillna(0)

# Popularity score (derived from purchase count and total hours)
max_purchases = game_stats['purchase_count'].max() if game_stats['purchase_count'].max() > 0 else 1
max_hours = game_stats['total_hours'].max() if game_stats['total_hours'].max() > 0 else 1

game_stats['popularity_score'] = (
    (game_stats['purchase_count'] / max_purchases * 60) + 
    (game_stats['total_hours'] / max_hours * 40)
).clip(0, 100)

# Engagement score (average hours per play session)
game_stats['engagement_score'] = game_stats['avg_hours'].clip(0, 200)

# Genre inference from game title (keyword-based)
print("   Inferring genres from game titles...")
def infer_genre(title):
    """Infer genre from game title using keyword matching"""
    title_lower = str(title).lower()
    
    # RPG keywords
    if any(word in title_lower for word in ['elder scrolls', 'fallout', 'dragon age', 'witcher', 
                                             'rpg', 'role-playing', 'final fantasy', 'mass effect',
                                             'divinity', 'pillars of eternity', 'baldur']):
        return 'RPG'
    # FPS keywords
    elif any(word in title_lower for word in ['left 4 dead', 'team fortress', 'counter-strike', 
                                               'call of duty', 'fps', 'shooter', 'half-life',
                                               'doom', 'quake', 'borderlands']):
        return 'FPS'
    # MMO keywords
    elif any(word in title_lower for word in ['dota', 'league', 'heroes of', 'mmo', 'mmorpg',
                                               'world of warcraft', 'guild wars', 'path of exile']):
        return 'MMO'
    # Strategy keywords
    elif any(word in title_lower for word in ['civilization', 'crusader', 'total war', 'strategy',
                                               'age of empires', 'starcraft', 'warcraft', 'xcom']):
        return 'Strategy'
    # Simulation keywords
    elif any(word in title_lower for word in ['simulator', 'sim', 'city', 'tycoon', 'simcity',
                                               'euro truck', 'farming', 'planet coaster']):
        return 'Simulation'
    # Racing keywords
    elif any(word in title_lower for word in ['racing', 'race', 'nfs', 'need for speed',
                                               'forza', 'grid', 'dirt', 'f1']):
        return 'Racing'
    # Sports keywords
    elif any(word in title_lower for word in ['football', 'soccer', 'fifa', 'nba', 'sport',
                                               'madden', 'nhl', 'pes']):
        return 'Sports'
    # Horror keywords
    elif any(word in title_lower for word in ['horror', 'dead', 'resident evil', 'silent hill',
                                               'outlast', 'amnesia', 'evil within']):
        return 'Horror'
    # Puzzle keywords
    elif any(word in title_lower for word in ['puzzle', 'bridge', 'match', 'tetris',
                                               'bejeweled', 'candy crush']):
        return 'Puzzle'
    # Adventure keywords
    elif any(word in title_lower for word in ['adventure', 'tomb raider', 'uncharted', 'explore',
                                               'journey', 'life is strange', 'walking dead']):
        return 'Adventure'
    # Indie keywords (smaller titles, often pixel art, etc.)
    elif any(word in title_lower for word in ['indie', 'pixel', 'retro', '8-bit']):
        return 'Indie'
    # Action (default for many games)
    else:
        return 'Action'

game_stats['genre'] = game_stats['game_title'].apply(infer_genre)

# Developer inference from game title (based on known franchises)
print("   Inferring developers from game titles...")
def infer_developer(title):
    """Infer developer/publisher from game title"""
    title_lower = str(title).lower()
    
    # Bethesda games
    if any(word in title_lower for word in ['elder scrolls', 'fallout', 'doom', 'wolfenstein']):
        return 'Bethesda'
    # Valve games
    elif any(word in title_lower for word in ['half-life', 'portal', 'team fortress', 
                                               'left 4 dead', 'counter-strike', 'dota 2']):
        return 'Valve'
    # EA games
    elif any(word in title_lower for word in ['fifa', 'madden', 'nhl', 'battlefield', 
                                               'mass effect', 'dragon age', 'sims', 'simcity']):
        return 'EA'
    # Ubisoft games
    elif any(word in title_lower for word in ['assassin', 'far cry', 'watch dogs', 
                                               'rainbow six', 'just dance', 'tom clancy']):
        return 'Ubisoft'
    # Rockstar games
    elif any(word in title_lower for word in ['grand theft auto', 'gta', 'red dead', 
                                               'max payne', 'bully']):
        return 'Rockstar'
    # CD Projekt games
    elif any(word in title_lower for word in ['witcher', 'cyberpunk']):
        return 'CD Projekt'
    # Blizzard games
    elif any(word in title_lower for word in ['world of warcraft', 'warcraft', 'starcraft',
                                               'diablo', 'overwatch', 'hearthstone']):
        return 'Blizzard'
    # Square Enix games
    elif any(word in title_lower for word in ['final fantasy', 'tomb raider', 'deus ex',
                                               'hitman', 'just cause']):
        return 'Square Enix'
    # 2K Games
    elif any(word in title_lower for word in ['bioshock', 'borderlands', 'civilization',
                                               'xcom', 'nba 2k']):
        return '2K Games'
    # Activision
    elif any(word in title_lower for word in ['call of duty', 'crash', 'spyro']):
        return 'Activision'
    # Capcom
    elif any(word in title_lower for word in ['resident evil', 'street fighter', 'monster hunter',
                                               'devil may cry', 'mega man']):
        return 'Capcom'
    # SEGA
    elif any(word in title_lower for word in ['sonic', 'sega', 'yakuza', 'total war']):
        return 'SEGA'
    # Default
    else:
        return 'Other'

game_stats['developer'] = game_stats['game_title'].apply(infer_developer)

# Release year inference (older games tend to have more purchases/playtime)
# We'll use a deterministic heuristic: games with high purchase_count are likely older
print("   Inferring release years from popularity patterns...")
def infer_release_year(row):
    """Infer release year based on popularity patterns (deterministic)"""
    purchase_count = row['purchase_count']
    total_hours = row['total_hours']
    
    # Very popular games (high purchase count) are likely older (established)
    # Use deterministic mapping based on percentiles
    if purchase_count > 1000:
        return 2011  # Classic/older games (around Skyrim era)
    elif purchase_count > 500:
        return 2013
    elif purchase_count > 100:
        return 2016
    elif total_hours > 10000:
        return 2014  # High engagement = established
    elif purchase_count > 50:
        return 2018
    elif purchase_count > 20:
        return 2020
    else:
        return 2022  # Newer/less popular

game_stats['release_year'] = game_stats.apply(infer_release_year, axis=1)

# Average rating inference (based on engagement - more playtime = higher rating)
print("   Inferring average ratings from engagement...")
def infer_rating(row):
    """Infer rating based on engagement metrics (deterministic)"""
    avg_hours = row['avg_hours']
    purchase_count = row['purchase_count']
    
    # High engagement and popularity = higher rating
    # Use deterministic formula based on normalized metrics
    if avg_hours > 50 and purchase_count > 100:
        return 4.5  # Highly engaging and popular
    elif avg_hours > 20 and purchase_count > 50:
        return 4.1
    elif avg_hours > 10:
        return 3.8
    elif purchase_count > 100:
        return 4.0  # Popular even if not highly engaging
    elif avg_hours > 5:
        return 3.5
    else:
        return 3.2  # Lower engagement

game_stats['average_rating'] = game_stats.apply(infer_rating, axis=1)

# ============================================================================
# USER-LEVEL FEATURES (derived from aggregated user behaviors)
# ============================================================================
print("\n3. CALCULATING USER-LEVEL FEATURES...")

user_stats = pd.DataFrame({
    'user_id': df['user_id'].unique()
})

# Total games owned (count of unique games purchased)
user_stats['total_games_owned'] = user_stats['user_id'].map(
    purchases.groupby('user_id')['game_title'].nunique()
).fillna(0).astype(int)

# Average playtime per game (from play records)
user_stats['average_playtime'] = user_stats['user_id'].map(
    plays.groupby('user_id')['value'].mean()
).fillna(0)

# Total playtime
user_stats['total_playtime'] = user_stats['user_id'].map(
    plays.groupby('user_id')['value'].sum()
).fillna(0)

# Preferred genre (genre with most total playtime)
print("   Calculating preferred genre from play history...")
play_with_genre = plays.copy()
play_with_genre = play_with_genre.merge(
    game_stats[['game_title', 'genre']], 
    on='game_title', 
    how='left'
)
play_with_genre['genre'] = play_with_genre['genre'].fillna('Action')

# Calculate total playtime per genre per user
user_genre_hours = play_with_genre.groupby(['user_id', 'genre'])['value'].sum().reset_index()
user_preferred = user_genre_hours.loc[user_genre_hours.groupby('user_id')['value'].idxmax()]

user_stats = user_stats.merge(
    user_preferred[['user_id', 'genre']].rename(columns={'genre': 'preferred_genre'}),
    on='user_id',
    how='left'
)
user_stats['preferred_genre'] = user_stats['preferred_genre'].fillna('Action')

# User engagement level (based on total games and playtime)
def calculate_engagement_level(row):
    """Categorize user engagement level"""
    games = row['total_games_owned']
    total_hours = row['total_playtime']
    
    if games > 50 and total_hours > 1000:
        return 'Hardcore'
    elif games > 20 and total_hours > 500:
        return 'Active'
    elif games > 10 and total_hours > 100:
        return 'Moderate'
    elif games > 5:
        return 'Casual'
    else:
        return 'Light'

user_stats['engagement_level'] = user_stats.apply(calculate_engagement_level, axis=1)

# ============================================================================
# INTERACTION-LEVEL FEATURES (derived from individual records)
# ============================================================================
print("\n4. CALCULATING INTERACTION-LEVEL FEATURES...")

# Merge game and user features into main dataframe
df = df.merge(user_stats, on='user_id', how='left')
df = df.merge(game_stats, on='game_title', how='left')

# Fill missing values
df['total_games_owned'] = df['total_games_owned'].fillna(0)
df['average_playtime'] = df['average_playtime'].fillna(0)
df['total_playtime'] = df['total_playtime'].fillna(0)
df['preferred_genre'] = df['preferred_genre'].fillna('Action')
df['engagement_level'] = df['engagement_level'].fillna('Light')
df['genre'] = df['genre'].fillna('Action')
df['developer'] = df['developer'].fillna('Other')
df['purchase_count'] = df['purchase_count'].fillna(0)
df['total_hours'] = df['total_hours'].fillna(0)
df['avg_hours'] = df['avg_hours'].fillna(0)
df['play_count'] = df['play_count'].fillna(0)
df['popularity_score'] = df['popularity_score'].fillna(0)
df['engagement_score'] = df['engagement_score'].fillna(0)
df['release_year'] = df['release_year'].fillna(2020)
df['average_rating'] = df['average_rating'].fillna(3.5)

# Hours played (for play records, this is the value; for purchases, 0)
df['hours_played'] = df.apply(
    lambda x: x['value'] if x['behavior_name'] == 'play' else 0.0,
    axis=1
)

# Inferred rating based on playtime and behavior
print("   Calculating inferred ratings from playtime...")
def calculate_inferred_rating(row):
    """Calculate rating based on playtime and purchase behavior (deterministic)"""
    if row['behavior_name'] == 'purchase':
        # Purchased - assume positive intent, rating 4
        return 4
    else:  # play
        hours = row['value']
        # Deterministic mapping based on playtime
        if hours > 100:
            return 5  # Very high engagement
        elif hours > 50:
            return 4  # High engagement
        elif hours > 10:
            return 3  # Moderate engagement
        elif hours > 1:
            return 2  # Low engagement
        else:
            return 1  # Very low engagement

df['inferred_rating'] = df.apply(calculate_inferred_rating, axis=1)

# Normalized preference score (0-1)
print("   Calculating normalized preference scores...")
df['normalized_preference'] = df.apply(
    lambda x: 1.0 if x['behavior_name'] == 'purchase'
    else min(1.0, x['value'] / 200.0),  # 200 hours = max preference
    axis=1
)

# Playtime category
def categorize_playtime(hours):
    """Categorize playtime into bins"""
    if hours == 0:
        return 'Not Played'
    elif hours < 1:
        return 'Very Low (<1h)'
    elif hours < 10:
        return 'Low (1-10h)'
    elif hours < 50:
        return 'Medium (10-50h)'
    elif hours < 100:
        return 'High (50-100h)'
    else:
        return 'Very High (100h+)'

df['playtime_category'] = df['hours_played'].apply(categorize_playtime)

# Genre match (does game genre match user's preferred genre?)
df['genre_match'] = (df['genre'] == df['preferred_genre']).astype(int)

# Relative playtime (hours played relative to game's average)
df['relative_playtime'] = df.apply(
    lambda x: x['hours_played'] / x['avg_hours'] if x['avg_hours'] > 0 and x['behavior_name'] == 'play' else 0,
    axis=1
)

# ============================================================================
# FINALIZE DATASET
# ============================================================================
print("\n5. FINALIZING DATASET...")

# Reorder columns for better readability
column_order = [
    # Original columns
    'user_id', 'game_title', 'behavior_name', 'value',
    # User features
    'total_games_owned', 'average_playtime', 'total_playtime', 'preferred_genre', 'engagement_level',
    # Game features
    'genre', 'developer', 'purchase_count', 'total_hours', 'avg_hours', 'play_count',
    'popularity_score', 'engagement_score', 'release_year', 'average_rating',
    # Interaction features
    'hours_played', 'playtime_category', 'inferred_rating', 'normalized_preference',
    'genre_match', 'relative_playtime'
]

df = df[column_order]

# Save enhanced dataset
output_file = 'steam-200k-enhanced-derived.csv'
print(f"\n6. SAVING ENHANCED DATASET...")
df.to_csv(output_file, index=False)
print(f"   ✓ Saved to: {output_file}")
print(f"   Total rows: {len(df):,}")
print(f"   Total columns: {len(df.columns)}")

# Print summary
print("\n" + "="*80)
print("FEATURE SUMMARY")
print("="*80)
print("\nORIGINAL COLUMNS (4):")
print("  - user_id, game_title, behavior_name, value")

print("\nUSER-LEVEL FEATURES (5) - Derived from user behavior aggregations:")
print("  - total_games_owned: Count of unique games purchased")
print("  - average_playtime: Average hours played per game")
print("  - total_playtime: Total hours played across all games")
print("  - preferred_genre: Genre with most total playtime")
print("  - engagement_level: User engagement category (Light/Casual/Moderate/Active/Hardcore)")

print("\nGAME-LEVEL FEATURES (10) - Derived from game title and aggregated behaviors:")
print("  - genre: Inferred from game title keywords")
print("  - developer: Inferred from game title keywords")
print("  - purchase_count: Number of unique users who purchased")
print("  - total_hours: Total hours played across all users")
print("  - avg_hours: Average hours per play session")
print("  - play_count: Number of play records")
print("  - popularity_score: Composite score (60% purchase count, 40% total hours)")
print("  - engagement_score: Average hours per play session (clipped)")
print("  - release_year: Inferred from popularity patterns")
print("  - average_rating: Inferred from engagement metrics")

print("\nINTERACTION-LEVEL FEATURES (6) - Derived from individual records:")
print("  - hours_played: Hours played (0 for purchases, value for plays)")
print("  - playtime_category: Categorical playtime bin")
print("  - inferred_rating: Rating (1-5) based on playtime")
print("  - normalized_preference: Normalized preference score (0-1)")
print("  - genre_match: Binary (1 if game genre matches user preferred genre)")
print("  - relative_playtime: Hours played relative to game's average")

print("\n" + "="*80)
print("TOTAL: 4 original + 21 derived = 25 columns")
print("="*80)
print("\n✓ Dataset enhancement complete!")
print(f"✓ All features are derived from original columns only")
print(f"✓ No simulated or random data added")

