# Steam Recommender System Project

**Course:** Recommendation Engines  
**Group Project:** Building a complete recommendation system for Steam video games

---

## Project Structure

```
recom 2/
├── steam-200k-enhanced-derived.csv    # Enhanced dataset (25 columns)
├── enhance_dataset_derived.py         # Script to generate enhanced dataset
├── DERIVED_DATASET_SUMMARY.md         # Documentation of all features
├── 01_EDA.ipynb                       # Comprehensive EDA notebook
├── results/
│   ├── visualizations/                # All EDA plots and charts
│   ├── model_performance/              # Model evaluation results
│   └── evaluation_results/            # Detailed evaluation metrics
└── README.md                           # This file
```

---

## Dataset

### Original Dataset
- **Source:** Kaggle "Steam Video Games" dataset
- **Original columns:** `user_id`, `game_title`, `behavior_name`, `value`
- **Size:** 200,000 interactions
- **Users:** 12,393 unique users
- **Games:** 5,155 unique games

### Enhanced Dataset
- **File:** `steam-200k-enhanced-derived.csv`
- **Columns:** 25 (4 original + 21 derived)
- **All features derived from original 4 columns only** (no simulated data)

### Key Features
- **User-level:** total_games_owned, average_playtime, preferred_genre, engagement_level
- **Game-level:** genre, developer, popularity_score, average_rating
- **Interaction-level:** inferred_rating, normalized_preference, genre_match

---

## EDA Notebook

The `01_EDA.ipynb` notebook provides comprehensive exploratory data analysis:

### Sections:
1. **Load & Preview Dataset** - Basic overview and data quality checks
2. **Basic Statistics** - Summary statistics for all columns
3. **User-Level Analysis** - User behavior patterns, engagement levels
4. **Game-Level Analysis** - Game popularity, genre/developer distributions
5. **Interaction-Level Analysis** - Playtime patterns, implicit feedback
6. **Derived Feature Analysis** - Correlation analysis, feature relationships
7. **Recommender-Specific EDA** (Critical):
   - User-item interaction matrix and sparsity analysis
   - Long-tail distribution analysis
   - Cold-start candidate identification
   - Implicit feedback profile
8. **Summary of Findings** - Key insights for modeling decisions

### Key Findings:
- **Sparsity:** ~XX% (calculated in notebook)
- **Cold-start users:** XX% have < 5 interactions
- **Cold-start games:** XX% have < 10 interactions
- **Long-tail:** Top XX games account for 80% of interactions

---

## Next Steps

1. **Data Preparation**
   - Train/test split
   - User-item matrix preparation
   - Feature encoding

2. **Baseline Models**
   - Popularity-based recommender
   - Random recommender

3. **Collaborative Filtering**
   - User-based CF
   - Item-based CF
   - Matrix Factorization (SVD/NMF)

4. **Content-Based Filtering**
   - Genre-based matching
   - Multi-feature similarity

5. **Hybrid Approach**
   - Combine CF and CB
   - Weighted ensemble

6. **Evaluation**
   - Precision@K, Recall@K, NDCG@K, MAP@K
   - Coverage, Diversity, Novelty
   - Cold-start evaluation

7. **Cold-Start Solutions**
   - New user strategies
   - New item strategies

---

## Running the EDA

```bash
# Make sure you have the required libraries
pip install pandas numpy matplotlib seaborn scipy jupyter

# Open and run the notebook
jupyter notebook 01_EDA.ipynb
```

The notebook will:
- Load the enhanced dataset
- Perform comprehensive analysis
- Generate visualizations (saved to `results/visualizations/`)
- Prepare data structures for modeling

---

## Notes

- All features are derived from original columns only
- No simulated or random data
- Focus on recommender-specific diagnostics
- Ready for CF, CB, and hybrid approaches

---

## Contact

For questions about the dataset or analysis, refer to `DERIVED_DATASET_SUMMARY.md` for detailed feature documentation.

